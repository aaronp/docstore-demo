import{aI as o,aJ as r}from"./index-b806cbf6.js";const s=(a,n)=>o.lang.round(r.parse(a)[n]),e=s;export{e as c};
