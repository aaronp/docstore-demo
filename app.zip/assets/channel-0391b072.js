import{aI as o,aJ as r}from"./index-cf0ccaa9.js";const s=(a,n)=>o.lang.round(r.parse(a)[n]),e=s;export{e as c};
