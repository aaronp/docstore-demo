import{c as r}from"./graph-69736f0a.js";var e=4;function a(o){return r(o,e)}export{a as c};
